const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validChatPayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    userId: uid,
    title: "Tajik Poetry & Math",
    languageCode: "tg",
    lastMessagePreview: "Салом! Чӣ тавр кӯмак кунам?",
    messageCount: 2,
    pinned: false,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validMessagePayload(uid, chatId, overrides = {}) {
  return {
    userId: uid,
    chatId,
    role: "user",
    text: "2x + 5 = 15 ро ҳал кун",
    createdAt: new Date(Date.now() - 1000),
    ...overrides,
  };
}

test("Unauthenticated user cannot read or write chats or messages", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("chats").get());
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("chats")
      .doc("chat_1")
      .set(validChatPayload(ALICE_UID))
  );
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("chats")
      .doc("chat_1")
      .collection("messages")
      .get()
  );
});

test("Owner can list empty chats, create chat, update allowed fields, and delete chat", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const chatsCol = aliceDb.collection("users").doc(ALICE_UID).collection("chats");

  // Empty subcollection list query with orderBy (matches Kotlin observeChats)
  await assertSucceeds(chatsCol.orderBy("updatedAt", "desc").get());

  // Create chat (NO @DocumentId `id` field)
  const chatRef = chatsCol.doc("chat_1");
  await assertSucceeds(chatRef.set(validChatPayload(ALICE_UID)));

  // Partial update: rename title
  await assertSucceeds(
    chatRef.update({
      title: "Quadratic Equations",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Partial update: pin toggle
  await assertSucceeds(
    chatRef.update({
      pinned: true,
      updatedAt: new Date(Date.now() - 400),
    })
  );

  // Partial update: languageMode
  await assertSucceeds(
    chatRef.update({
      languageCode: "ru",
      updatedAt: new Date(Date.now() - 300),
    })
  );

  // Partial update: lastMessagePreview + messageCount + title
  await assertSucceeds(
    chatRef.update({
      title: "Updated Chat Title",
      lastMessagePreview: "Ответ готов!",
      messageCount: 4,
      updatedAt: new Date(Date.now() - 200),
    })
  );

  await assertSucceeds(chatRef.delete());
});

test("Owner can create, list, and delete messages inside owned chat; updates are forbidden", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const chatRef = aliceDb.collection("users").doc(ALICE_UID).collection("chats").doc("chat_1");
  await assertSucceeds(chatRef.set(validChatPayload(ALICE_UID)));

  const messagesCol = chatRef.collection("messages");
  await assertSucceeds(messagesCol.orderBy("createdAt", "asc").get());

  // Create user message without optional taskTag
  await assertSucceeds(messagesCol.doc("msg_1").set(validMessagePayload(ALICE_UID, "chat_1")));

  // Create model message with optional taskTag
  await assertSucceeds(
    messagesCol.doc("msg_2").set(
      validMessagePayload(ALICE_UID, "chat_1", {
        role: "model",
        text: "x = 5",
        taskTag: "math",
      })
    )
  );

  // Message updates are immutable/forbidden
  await assertFails(messagesCol.doc("msg_1").update({ text: "Tampered" }));

  // Message deletion by owner succeeds
  await assertSucceeds(messagesCol.doc("msg_1").delete());
});

test("Rejects ghost fields, @DocumentId id field, immutable mutations, and invalid bounds", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const chatsCol = aliceDb.collection("users").doc(ALICE_UID).collection("chats");
  const chatRef = chatsCol.doc("chat_1");
  await assertSucceeds(chatRef.set(validChatPayload(ALICE_UID)));

  // Reject ghost field on create
  await assertFails(
    chatsCol.doc("chat_ghost").set(validChatPayload(ALICE_UID, { isVerified: true }))
  );

  // Reject `@DocumentId` id field on create
  await assertFails(
    chatsCol.doc("chat_with_id").set(validChatPayload(ALICE_UID, { id: "chat_with_id" }))
  );

  // Reject invalid languageCode
  await assertFails(
    chatsCol.doc("chat_bad_lang").set(validChatPayload(ALICE_UID, { languageCode: "fr" }))
  );

  // Reject future timestamp
  await assertFails(
    chatsCol.doc("chat_future").set(
      validChatPayload(ALICE_UID, { createdAt: new Date(Date.now() + 60000) })
    )
  );

  // Reject immutable createdAt update
  await assertFails(
    chatRef.update({
      createdAt: new Date(Date.now() - 100),
      updatedAt: new Date(Date.now() - 100),
    })
  );

  // Reject invalid role or empty text in message
  await assertFails(
    chatRef.collection("messages").doc("msg_bad_role").set(
      validMessagePayload(ALICE_UID, "chat_1", { role: "system" })
    )
  );
  await assertFails(
    chatRef.collection("messages").doc("msg_empty").set(
      validMessagePayload(ALICE_UID, "chat_1", { text: "" })
    )
  );
  await assertFails(
    chatRef.collection("messages").doc("msg_bad_tag").set(
      validMessagePayload(ALICE_UID, "chat_1", { taskTag: "hack" })
    )
  );
});

test("Cross-user isolation: Bob cannot read, list, create, update, or delete Alice's data", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const aliceChat = aliceDb.collection("users").doc(ALICE_UID).collection("chats").doc("chat_1");
  await assertSucceeds(aliceChat.set(validChatPayload(ALICE_UID)));
  await assertSucceeds(
    aliceChat.collection("messages").doc("msg_1").set(validMessagePayload(ALICE_UID, "chat_1"))
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const bobTargetsAliceChats = bobDb.collection("users").doc(ALICE_UID).collection("chats");

  await assertFails(bobTargetsAliceChats.get());
  await assertFails(bobTargetsAliceChats.doc("chat_1").get());
  await assertFails(bobTargetsAliceChats.doc("chat_2").set(validChatPayload(BOB_UID)));
  await assertFails(
    bobTargetsAliceChats.doc("chat_1").update({ title: "Hijacked", updatedAt: new Date(Date.now() - 100) })
  );
  await assertFails(bobTargetsAliceChats.doc("chat_1").delete());
  await assertFails(bobTargetsAliceChats.doc("chat_1").collection("messages").get());
  await assertFails(
    bobTargetsAliceChats
      .doc("chat_1")
      .collection("messages")
      .doc("msg_2")
      .set(validMessagePayload(BOB_UID, "chat_1"))
  );
});
