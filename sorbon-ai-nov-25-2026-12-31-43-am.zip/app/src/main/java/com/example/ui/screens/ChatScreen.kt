package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddComment
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.QuestionAnswer
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.auth.signOut
import com.example.data.model.CapabilityMode
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.data.model.LanguageMode
import com.example.data.model.UiState
import com.example.data.repository.ChatRepository
import com.example.data.repository.GeminiAiRepository
import com.example.ui.components.ChatHistoryPanel
import com.example.ui.components.MarkdownMessageText
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.StreamingUiState
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

@Composable
fun MainChatRoute(
    currentUserId: String,
    userDisplayName: String,
    userEmail: String,
    userPhotoUrl: String?
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: ChatViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val appContext = context.applicationContext
                val databaseId = appContext.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                ChatViewModel(
                    chatRepository = ChatRepository(db),
                    geminiAiRepository = GeminiAiRepository(),
                    currentUserId = currentUserId
                )
            }
        }
    )

    ChatScreen(
        viewModel = viewModel,
        userDisplayName = userDisplayName,
        userEmail = userEmail,
        userPhotoUrl = userPhotoUrl,
        onSignOut = {
            signOut(credentialManager = credentialManager, scope = scope)
        }
    )
}

@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    userDisplayName: String,
    userEmail: String,
    userPhotoUrl: String?,
    onSignOut: () -> Unit
) {
    val chatsState by viewModel.chatsState.collectAsStateWithLifecycle()
    val activeChatId by viewModel.activeChatId.collectAsStateWithLifecycle()
    val messagesState by viewModel.messagesState.collectAsStateWithLifecycle()
    val inputText by viewModel.inputText.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val selectedCapability by viewModel.selectedCapability.collectAsStateWithLifecycle()
    val streamingState by viewModel.streamingState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val bannerError by viewModel.bannerError.collectAsStateWithLifecycle()
    val cooldownSeconds by viewModel.cooldownSecondsRemaining.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val copiedToastMessage = stringResource(id = R.string.copied_to_clipboard)

    LaunchedEffect(bannerError) {
        val message = bannerError
        if (!message.isNullOrBlank()) {
            snackbarHostState.showSnackbar(message)
            viewModel.dismissBannerError()
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpandedWidth = maxWidth >= 840.dp

        if (isExpandedWidth) {
            Row(modifier = Modifier.fillMaxSize()) {
                ChatHistoryPanel(
                    chatsState = chatsState,
                    activeChatId = activeChatId,
                    searchQuery = searchQuery,
                    userDisplayName = userDisplayName,
                    userEmail = userEmail,
                    userPhotoUrl = userPhotoUrl,
                    onSearchQueryChange = viewModel::onSearchQueryChanged,
                    onNewChat = viewModel::startNewChat,
                    onSelectChat = viewModel::selectChat,
                    onRenameChat = viewModel::renameChat,
                    onTogglePin = viewModel::togglePinChat,
                    onDeleteChat = viewModel::deleteChat,
                    onSignOut = onSignOut,
                    modifier = Modifier.width(300.dp)
                )
                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(1.dp),
                    color = MaterialTheme.colorScheme.outlineVariant
                )
                ChatScaffoldContent(
                    showMenuButton = false,
                    onOpenDrawer = {},
                    chatsState = chatsState,
                    activeChatId = activeChatId,
                    messagesState = messagesState,
                    inputText = inputText,
                    selectedLanguage = selectedLanguage,
                    selectedCapability = selectedCapability,
                    streamingState = streamingState,
                    cooldownSeconds = cooldownSeconds,
                    snackbarHostState = snackbarHostState,
                    onSelectLanguage = viewModel::selectLanguage,
                    onSelectCapability = viewModel::selectCapability,
                    onNewChat = viewModel::startNewChat,
                    onInputChanged = viewModel::onInputChanged,
                    onSendMessage = { viewModel.sendMessage(null) },
                    onStarterClick = { capability, prompt ->
                        viewModel.selectCapability(capability)
                        viewModel.sendMessage(prompt)
                    },
                    onStopGenerating = viewModel::stopGenerating,
                    onRetry = viewModel::retryLastError,
                    onCopied = {
                        scope.launch { snackbarHostState.showSnackbar(copiedToastMessage) }
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        } else {
            val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        modifier = Modifier.widthIn(max = 312.dp),
                        drawerContainerColor = MaterialTheme.colorScheme.surface
                    ) {
                        ChatHistoryPanel(
                            chatsState = chatsState,
                            activeChatId = activeChatId,
                            searchQuery = searchQuery,
                            userDisplayName = userDisplayName,
                            userEmail = userEmail,
                            userPhotoUrl = userPhotoUrl,
                            onSearchQueryChange = viewModel::onSearchQueryChanged,
                            onNewChat = {
                                viewModel.startNewChat()
                                scope.launch { drawerState.close() }
                            },
                            onSelectChat = { chat ->
                                viewModel.selectChat(chat)
                                scope.launch { drawerState.close() }
                            },
                            onRenameChat = viewModel::renameChat,
                            onTogglePin = viewModel::togglePinChat,
                            onDeleteChat = viewModel::deleteChat,
                            onSignOut = {
                                scope.launch { drawerState.close() }
                                onSignOut()
                            }
                        )
                    }
                }
            ) {
                ChatScaffoldContent(
                    showMenuButton = true,
                    onOpenDrawer = { scope.launch { drawerState.open() } },
                    chatsState = chatsState,
                    activeChatId = activeChatId,
                    messagesState = messagesState,
                    inputText = inputText,
                    selectedLanguage = selectedLanguage,
                    selectedCapability = selectedCapability,
                    streamingState = streamingState,
                    cooldownSeconds = cooldownSeconds,
                    snackbarHostState = snackbarHostState,
                    onSelectLanguage = viewModel::selectLanguage,
                    onSelectCapability = viewModel::selectCapability,
                    onNewChat = viewModel::startNewChat,
                    onInputChanged = viewModel::onInputChanged,
                    onSendMessage = { viewModel.sendMessage(null) },
                    onStarterClick = { capability, prompt ->
                        viewModel.selectCapability(capability)
                        viewModel.sendMessage(prompt)
                    },
                    onStopGenerating = viewModel::stopGenerating,
                    onRetry = viewModel::retryLastError,
                    onCopied = {
                        scope.launch { snackbarHostState.showSnackbar(copiedToastMessage) }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
private fun ChatScaffoldContent(
    showMenuButton: Boolean,
    onOpenDrawer: () -> Unit,
    chatsState: UiState<List<ChatSession>>,
    activeChatId: String?,
    messagesState: UiState<List<ChatMessage>>,
    inputText: String,
    selectedLanguage: LanguageMode,
    selectedCapability: CapabilityMode,
    streamingState: StreamingUiState,
    cooldownSeconds: Int,
    snackbarHostState: SnackbarHostState,
    onSelectLanguage: (LanguageMode) -> Unit,
    onSelectCapability: (CapabilityMode) -> Unit,
    onNewChat: () -> Unit,
    onInputChanged: (String) -> Unit,
    onSendMessage: () -> Unit,
    onStarterClick: (CapabilityMode, String) -> Unit,
    onStopGenerating: () -> Unit,
    onRetry: () -> Unit,
    onCopied: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeChatTitle = remember(chatsState, activeChatId) {
        if (activeChatId == null) {
            null
        } else {
            (chatsState as? UiState.Success)?.data?.firstOrNull { it.id == activeChatId }?.title
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            SorbonTopBar(
                title = activeChatTitle ?: stringResource(id = R.string.app_name),
                showMenuButton = showMenuButton,
                selectedLanguage = selectedLanguage,
                onOpenDrawer = onOpenDrawer,
                onSelectLanguage = onSelectLanguage,
                onNewChat = onNewChat
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
        ) {
            // Conversation Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.TopCenter
            ) {
                when (messagesState) {
                    is UiState.Loading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    is UiState.Error -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(18.dp)
                            ) {
                                Text(
                                    text = messagesState.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                    }

                    is UiState.Success -> {
                        val messages = messagesState.data
                        val isGenerating = streamingState is StreamingUiState.Connecting ||
                            streamingState is StreamingUiState.Streaming
                        val showConversation = messages.isNotEmpty() ||
                            isGenerating ||
                            streamingState is StreamingUiState.Error

                        if (!showConversation) {
                            WelcomeEmptyState(
                                selectedLanguage = selectedLanguage,
                                enabled = cooldownSeconds == 0 && !isGenerating,
                                onStarterClick = onStarterClick,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .widthIn(max = 760.dp)
                            )
                        } else {
                            ConversationList(
                                messages = messages,
                                streamingState = streamingState,
                                selectedLanguage = selectedLanguage,
                                cooldownSeconds = cooldownSeconds,
                                onRetry = onRetry,
                                onCopied = onCopied,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .widthIn(max = 760.dp)
                            )
                        }
                    }
                }
            }

            // Bottom Composer Bar
            ChatComposerBar(
                inputText = inputText,
                selectedLanguage = selectedLanguage,
                selectedCapability = selectedCapability,
                isGenerating = streamingState is StreamingUiState.Connecting ||
                    streamingState is StreamingUiState.Streaming,
                isCoolingDown = cooldownSeconds > 0,
                onInputChanged = onInputChanged,
                onSelectCapability = onSelectCapability,
                onSend = onSendMessage,
                onStop = onStopGenerating
            )
        }
    }
}

@Composable
private fun SorbonTopBar(
    title: String,
    showMenuButton: Boolean,
    selectedLanguage: LanguageMode,
    onOpenDrawer: () -> Unit,
    onSelectLanguage: (LanguageMode) -> Unit,
    onNewChat: () -> Unit
) {
    var langMenuExpanded by remember { mutableStateOf(false) }

    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
        tonalElevation = 1.dp
    ) {
        Column(modifier = Modifier.statusBarsPadding()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (showMenuButton) {
                    IconButton(
                        onClick = onOpenDrawer,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("history_drawer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Menu,
                            contentDescription = stringResource(id = R.string.open_history),
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.width(12.dp))
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Language Selector Pill
                Box {
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable { langMenuExpanded = true }
                            .testTag("language_selector_button"),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Language,
                                contentDescription = "Language mode",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = selectedLanguage.nativeLabel,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Icon(
                                imageVector = Icons.Rounded.ExpandMore,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = langMenuExpanded,
                        onDismissRequest = { langMenuExpanded = false }
                    ) {
                        LanguageMode.entries.forEach { mode ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = mode.nativeLabel,
                                            fontWeight = if (mode == selectedLanguage) {
                                                FontWeight.Bold
                                            } else {
                                                FontWeight.Normal
                                            }
                                        )
                                        Text(
                                            text = mode.shortBadge,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                },
                                onClick = {
                                    langMenuExpanded = false
                                    onSelectLanguage(mode)
                                }
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onNewChat,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("top_new_chat_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AddComment,
                        contentDescription = stringResource(id = R.string.new_chat),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        }
    }
}

private data class StarterSuggestion(
    val capability: CapabilityMode,
    val icon: ImageVector,
    val title: String,
    val subtitle: String,
    val prompt: String
)

@Composable
private fun WelcomeEmptyState(
    selectedLanguage: LanguageMode,
    enabled: Boolean,
    onStarterClick: (CapabilityMode, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val greetingTitle = when (selectedLanguage) {
        LanguageMode.TAJIK -> "Салом! Ман Sorbon AI ҳастам"
        LanguageMode.RUSSIAN -> "Привет! Я Sorbon AI"
        LanguageMode.ENGLISH, LanguageMode.AUTO -> "Hello! I'm Sorbon AI"
    }
    val greetingSubtitle = when (selectedLanguage) {
        LanguageMode.TAJIK -> "Савол пурсед, матн нависед, тарҷума кунед ё масъалаҳои математикӣ ҳал намоед."
        LanguageMode.RUSSIAN -> "Задавайте вопросы, пишите тексты, переводите языки и решайте задачи по математике."
        LanguageMode.ENGLISH -> "Ask questions, draft texts, translate between languages, and solve math step by step."
        LanguageMode.AUTO -> "Speak in Тоҷикӣ, Русский, or English — ask questions, write texts, translate, or solve math."
    }

    val starters = remember(selectedLanguage) {
        when (selectedLanguage) {
            LanguageMode.TAJIK -> listOf(
                StarterSuggestion(
                    CapabilityMode.CHAT,
                    Icons.Rounded.QuestionAnswer,
                    "Савол диҳед",
                    "Дар бораи таърих ва илм пурсед",
                    "Дар бораи таърихи Исмоили Сомонӣ маълумоти мухтасар ва ҷолиб диҳед."
                ),
                StarterSuggestion(
                    CapabilityMode.WRITE,
                    Icons.Rounded.EditNote,
                    "Навиштани матн",
                    "Мактуб, иншо ё табрикнома",
                    "Барои дӯстам ба муносибати Наврӯз як табрикномаи зебо навис."
                ),
                StarterSuggestion(
                    CapabilityMode.TRANSLATE,
                    Icons.Rounded.Translate,
                    "Тарҷумаи забонҳо",
                    "Тоҷикӣ ⇄ Русский ⇄ English",
                    "Ин ҷумларо ба русӣ ва англисӣ тарҷума кун: «Дониш чароғи ақл аст»."
                ),
                StarterSuggestion(
                    CapabilityMode.MATH,
                    Icons.Rounded.Calculate,
                    "Ҳалли математика",
                    "Муодилаҳо бо шарҳи қадам ба қадам",
                    "Муодилаи квадратии x² - 5x + 6 = 0 ро қадам ба қадам ҳал кун."
                )
            )
            LanguageMode.RUSSIAN -> listOf(
                StarterSuggestion(
                    CapabilityMode.CHAT,
                    Icons.Rounded.QuestionAnswer,
                    "Задать вопрос",
                    "Четкие ответы на любую тему",
                    "Объясни простыми словами, как работает искусственный интеллект."
                ),
                StarterSuggestion(
                    CapabilityMode.WRITE,
                    Icons.Rounded.EditNote,
                    "Написать текст",
                    "Письма, эссе, посты и статьи",
                    "Напиши деловое письмо с благодарностью коллегам за успешный проект."
                ),
                StarterSuggestion(
                    CapabilityMode.TRANSLATE,
                    Icons.Rounded.Translate,
                    "Переводчик",
                    "Русский ⇄ Тоҷикӣ ⇄ English",
                    "Переведи на таджикский и английский: «Знание — сила, а терпение — ключ к успеху»."
                ),
                StarterSuggestion(
                    CapabilityMode.MATH,
                    Icons.Rounded.Calculate,
                    "Решить задачу",
                    "Пошаговое решение формул",
                    "Реши по шагам систему уравнений: 2x + y = 10 и x - y = 2."
                )
            )
            LanguageMode.ENGLISH, LanguageMode.AUTO -> listOf(
                StarterSuggestion(
                    CapabilityMode.CHAT,
                    Icons.Rounded.QuestionAnswer,
                    "Answer Questions",
                    "Clear explanations on any topic",
                    "Explain how solar panels convert sunlight into electricity in simple steps."
                ),
                StarterSuggestion(
                    CapabilityMode.WRITE,
                    Icons.Rounded.EditNote,
                    "Write & Draft Texts",
                    "Essays, emails, stories, poems",
                    "Write a concise, warm welcome email for a new software engineer joining the team."
                ),
                StarterSuggestion(
                    CapabilityMode.TRANSLATE,
                    Icons.Rounded.Translate,
                    "Translate TJ · RU · EN",
                    "Fluent trilingual translation",
                    "Translate \"Welcome to Dushanbe, the heart of Tajikistan!\" into Tajik and Russian."
                ),
                StarterSuggestion(
                    CapabilityMode.MATH,
                    Icons.Rounded.Calculate,
                    "Solve Math Step-by-Step",
                    "Algebra, geometry & calculus",
                    "Solve 3x² - 12x + 9 = 0 step by step and verify the roots."
                )
            )
        }
    }

    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Branded Hero Banner Card
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(id = R.drawable.img_sorbon_banner_1795523578271),
                    contentDescription = stringResource(id = R.string.cd_hero_banner),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .matchParentSize()
                        .alpha(0.32f)
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                                    MaterialTheme.colorScheme.surface.copy(alpha = 0.65f)
                                )
                            )
                        )
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_sorbon_logo_1795523578855),
                        contentDescription = stringResource(id = R.string.cd_sorbon_logo),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                                RoundedCornerShape(16.dp)
                            )
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = greetingTitle,
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = greetingSubtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 2x2 Responsive Starter Grid
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            starters.chunked(2).forEach { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    pair.forEach { item ->
                        StarterSuggestionCard(
                            suggestion = item,
                            enabled = enabled,
                            onClick = { onStarterClick(item.capability, item.prompt) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StarterSuggestionCard(
    suggestion: StarterSuggestion,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .alpha(if (enabled) 1f else 0.6f)
            .testTag("starter_card_${suggestion.capability.tag}"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = suggestion.icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(
                text = suggestion.title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = suggestion.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ConversationList(
    messages: List<ChatMessage>,
    streamingState: StreamingUiState,
    selectedLanguage: LanguageMode,
    cooldownSeconds: Int,
    onRetry: () -> Unit,
    onCopied: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val streamingTextLength = (streamingState as? StreamingUiState.Streaming)?.text?.length ?: 0

    LaunchedEffect(messages.size, streamingTextLength, streamingState) {
        val totalItems = messages.size +
            if (streamingState !is StreamingUiState.Idle) 1 else 0
        if (totalItems > 0) {
            listState.animateScrollToItem(totalItems - 1)
        }
    }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(messages, key = { it.id }) { message ->
            if (message.isFromUser) {
                UserMessageBubble(message = message)
            } else {
                AssistantMessageRow(
                    text = message.text,
                    taskTag = message.taskTag,
                    isStreaming = false,
                    onCopied = onCopied
                )
            }
        }

        when (streamingState) {
            is StreamingUiState.Connecting -> {
                item(key = "streaming_connecting") {
                    ThinkingIndicatorRow()
                }
            }

            is StreamingUiState.Streaming -> {
                item(key = "streaming_active") {
                    AssistantMessageRow(
                        text = streamingState.text,
                        taskTag = null,
                        isStreaming = true,
                        onCopied = onCopied
                    )
                }
            }

            is StreamingUiState.Error -> {
                item(key = "streaming_error") {
                    ErrorRetryCard(
                        message = streamingState.message,
                        quotaExhausted = streamingState.quotaExhausted,
                        selectedLanguage = selectedLanguage,
                        cooldownSeconds = cooldownSeconds,
                        onRetry = onRetry
                    )
                }
            }

            is StreamingUiState.Idle -> Unit
        }
    }
}

@Composable
private fun UserMessageBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 320.dp),
            shape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = 20.dp,
                bottomEnd = 6.dp
            ),
            color = MaterialTheme.colorScheme.primaryContainer
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                val tag = message.taskTag
                if (!tag.isNullOrBlank() && tag != CapabilityMode.CHAT.tag) {
                    Text(
                        text = tag.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }
}

@Composable
private fun AssistantMessageRow(
    text: String,
    taskTag: String?,
    isStreaming: Boolean,
    onCopied: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_sorbon_logo_1795523578855),
            contentDescription = stringResource(id = R.string.cd_sorbon_logo),
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), CircleShape)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = stringResource(id = R.string.app_name),
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (!taskTag.isNullOrBlank() && taskTag != CapabilityMode.CHAT.tag) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = taskTag.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            MarkdownMessageText(
                text = text,
                textColor = MaterialTheme.colorScheme.onBackground,
                onCodeCopied = onCopied
            )

            if (isStreaming) {
                Spacer(modifier = Modifier.height(6.dp))
                StreamingPulseIndicator()
            } else {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(text))
                            onCopied()
                        },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ContentCopy,
                            contentDescription = stringResource(id = R.string.copy),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, text)
                            }
                            context.startActivity(
                                Intent.createChooser(shareIntent, "Share Sorbon AI response")
                            )
                        },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Share,
                            contentDescription = "Share response",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ThinkingIndicatorRow() {
    val transition = rememberInfiniteTransition(label = "thinking_pulse")
    val alpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(650),
            repeatMode = RepeatMode.Reverse
        ),
        label = "thinking_alpha"
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_sorbon_logo_1795523578855),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .alpha(alpha)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Surface(
            color = MaterialTheme.colorScheme.surfaceContainer,
            shape = RoundedCornerShape(14.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .size(16.dp)
                        .alpha(alpha)
                )
                Text(
                    text = "Sorbon AI is thinking...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun StreamingPulseIndicator() {
    val transition = rememberInfiniteTransition(label = "cursor_pulse")
    val alpha by transition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(450),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursor_alpha"
    )
    Box(
        modifier = Modifier
            .size(width = 10.dp, height = 16.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = alpha))
    )
}

@Composable
private fun ErrorRetryCard(
    message: String,
    quotaExhausted: Boolean,
    selectedLanguage: LanguageMode,
    cooldownSeconds: Int,
    onRetry: () -> Unit
) {
    val containerColor = if (quotaExhausted) {
        MaterialTheme.colorScheme.secondaryContainer
    } else {
        MaterialTheme.colorScheme.errorContainer
    }
    val contentColor = if (quotaExhausted) {
        MaterialTheme.colorScheme.onSecondaryContainer
    } else {
        MaterialTheme.colorScheme.onErrorContainer
    }
    val buttonContainer = if (quotaExhausted) {
        MaterialTheme.colorScheme.secondary
    } else {
        MaterialTheme.colorScheme.error
    }
    val buttonContent = if (quotaExhausted) {
        MaterialTheme.colorScheme.onSecondary
    } else {
        MaterialTheme.colorScheme.onError
    }

    Surface(
        color = containerColor,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(if (quotaExhausted) "quota_error_card" else "error_card")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (quotaExhausted) {
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.HourglassBottom,
                        contentDescription = null,
                        tint = contentColor,
                        modifier = Modifier
                            .size(22.dp)
                            .padding(top = 2.dp)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = stringResource(id = R.string.error_quota_exhausted_tg),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = contentColor,
                            modifier = Modifier.testTag("quota_tajik_message")
                        )
                        if (selectedLanguage == LanguageMode.RUSSIAN) {
                            Text(
                                text = stringResource(id = R.string.error_quota_exhausted_ru),
                                style = MaterialTheme.typography.bodySmall,
                                color = contentColor.copy(alpha = 0.85f)
                            )
                        } else if (selectedLanguage == LanguageMode.ENGLISH) {
                            Text(
                                text = stringResource(id = R.string.error_quota_exhausted_en),
                                style = MaterialTheme.typography.bodySmall,
                                color = contentColor.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            } else {
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = contentColor
                )
            }

            Button(
                onClick = onRetry,
                enabled = cooldownSeconds == 0,
                modifier = Modifier
                    .height(48.dp)
                    .testTag("retry_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = buttonContainer,
                    contentColor = buttonContent
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (cooldownSeconds > 0) {
                        stringResource(id = R.string.quota_wait_seconds, cooldownSeconds)
                    } else {
                        stringResource(id = R.string.retry)
                    }
                )
            }
        }
    }
}

@Composable
private fun ChatComposerBar(
    inputText: String,
    selectedLanguage: LanguageMode,
    selectedCapability: CapabilityMode,
    isGenerating: Boolean,
    isCoolingDown: Boolean,
    onInputChanged: (String) -> Unit,
    onSelectCapability: (CapabilityMode) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit
) {
    val placeholderText = when (selectedLanguage) {
        LanguageMode.TAJIK -> "Аз Sorbon AI пурсед..."
        LanguageMode.RUSSIAN -> "Спросите Sorbon AI..."
        LanguageMode.ENGLISH -> "Ask Sorbon AI..."
        LanguageMode.AUTO -> "Message Sorbon AI (TJ / RU / EN)..."
    }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.widthIn(max = 760.dp)) {
                // Quick Capability Mode Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CapabilityMode.entries.forEach { mode ->
                        val selected = mode == selectedCapability
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectCapability(mode) },
                            label = {
                                Text(
                                    text = mode.labelFor(selectedLanguage),
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            leadingIcon = {
                                val icon = when (mode) {
                                    CapabilityMode.CHAT -> Icons.Rounded.QuestionAnswer
                                    CapabilityMode.WRITE -> Icons.Rounded.EditNote
                                    CapabilityMode.TRANSLATE -> Icons.Rounded.Translate
                                    CapabilityMode.MATH -> Icons.Rounded.Calculate
                                }
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                selectedLeadingIconColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("capability_chip_${mode.tag}")
                        )
                    }
                }

                // Rounded Message Input Box
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 12.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        TextField(
                            value = inputText,
                            onValueChange = onInputChanged,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("message_input_field"),
                            placeholder = {
                                Text(
                                    text = placeholderText,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            maxLines = 5,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Sentences,
                                imeAction = ImeAction.Send
                            ),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (!isGenerating && !isCoolingDown && inputText.isNotBlank()) {
                                        onSend()
                                    }
                                }
                            ),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                disabledIndicatorColor = Color.Transparent,
                                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                            ),
                            textStyle = MaterialTheme.typography.bodyLarge
                        )

                        Spacer(modifier = Modifier.width(4.dp))

                        AnimatedVisibility(visible = isGenerating) {
                            IconButton(
                                onClick = onStop,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.errorContainer)
                                    .testTag("stop_generating_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Stop,
                                    contentDescription = stringResource(id = R.string.stop_generating),
                                    tint = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }

                        if (!isGenerating) {
                            val canSend = inputText.isNotBlank() && !isCoolingDown
                            IconButton(
                                onClick = onSend,
                                enabled = canSend,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (canSend) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.surfaceContainerHighest
                                        }
                                    )
                                    .testTag("send_message_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Send,
                                    contentDescription = stringResource(id = R.string.send_message),
                                    tint = if (canSend) {
                                        MaterialTheme.colorScheme.onPrimary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
