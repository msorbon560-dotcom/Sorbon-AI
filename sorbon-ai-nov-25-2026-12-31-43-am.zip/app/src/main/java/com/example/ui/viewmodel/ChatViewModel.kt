package com.example.ui.viewmodel

import android.os.SystemClock
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CapabilityMode
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.data.model.LanguageMode
import com.example.data.model.UiState
import com.example.data.repository.ChatRepository
import com.example.data.repository.GeminiAiRepository
import com.example.data.repository.QuotaExhaustedException
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

private const val TAG = "ChatViewModel"
private const val STOP_TIMEOUT_MILLIS = 5000L
private const val DUPLICATE_GUARD_WINDOW_MS = 1200L
private const val QUOTA_COOLDOWN_SECONDS = 10

sealed interface StreamingUiState {
    data object Idle : StreamingUiState
    data object Connecting : StreamingUiState
    data class Streaming(val text: String) : StreamingUiState
    data class Error(
        val message: String,
        val retryPrompt: String,
        val userMessageAlreadySaved: Boolean,
        val quotaExhausted: Boolean = false
    ) : StreamingUiState
}

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(
    private val chatRepository: ChatRepository,
    private val geminiAiRepository: GeminiAiRepository,
    private val currentUserId: String
) : ViewModel() {

    val chatsState: StateFlow<UiState<List<ChatSession>>> = chatRepository.observeChats(currentUserId)
        .map<List<ChatSession>, UiState<List<ChatSession>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing chats", rootError)
            emit(UiState.Error(rootError.localizedMessage ?: "Failed to load chat history"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    private val _activeChatId = MutableStateFlow<String?>(null)
    val activeChatId: StateFlow<String?> = _activeChatId.asStateFlow()

    val messagesState: StateFlow<UiState<List<ChatMessage>>> = _activeChatId
        .flatMapLatest { chatId ->
            if (chatId == null) {
                flowOf(UiState.Success(emptyList()))
            } else {
                chatRepository.observeMessages(currentUserId, chatId)
                    .map<List<ChatMessage>, UiState<List<ChatMessage>>> { UiState.Success(it) }
                    .catch { error ->
                        val firestoreError = generateSequence(error) { it.cause }
                            .filterIsInstance<FirebaseFirestoreException>()
                            .firstOrNull()
                        if (firestoreError == null && error is CancellationException) throw error
                        val rootError = firestoreError ?: error
                        Log.w(TAG, "Error observing messages", rootError)
                        emit(UiState.Error(rootError.localizedMessage ?: "Failed to load messages"))
                    }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Success(emptyList())
        )

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(LanguageMode.AUTO)
    val selectedLanguage: StateFlow<LanguageMode> = _selectedLanguage.asStateFlow()

    private val _selectedCapability = MutableStateFlow(CapabilityMode.CHAT)
    val selectedCapability: StateFlow<CapabilityMode> = _selectedCapability.asStateFlow()

    private val _streamingState = MutableStateFlow<StreamingUiState>(StreamingUiState.Idle)
    val streamingState: StateFlow<StreamingUiState> = _streamingState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _bannerError = MutableStateFlow<String?>(null)
    val bannerError: StateFlow<String?> = _bannerError.asStateFlow()

    private val _cooldownSecondsRemaining = MutableStateFlow(0)
    val cooldownSecondsRemaining: StateFlow<Int> = _cooldownSecondsRemaining.asStateFlow()

    private var streamingJob: Job? = null
    private var cooldownJob: Job? = null
    private val requestInFlight = AtomicBoolean(false)
    private var lastDispatchSignature: String? = null
    private var lastDispatchElapsedMs: Long = 0L

    fun onInputChanged(value: String) {
        _inputText.value = value
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun dismissBannerError() {
        _bannerError.value = null
    }

    fun selectLanguage(mode: LanguageMode) {
        if (_selectedLanguage.value == mode) return
        _selectedLanguage.value = mode
        val chatId = _activeChatId.value ?: return
        viewModelScope.launch {
            chatRepository.updateChatLanguage(currentUserId, chatId, mode).onFailure { err ->
                _bannerError.value = err.localizedMessage ?: "Could not update language preference."
            }
        }
    }

    fun selectCapability(mode: CapabilityMode) {
        _selectedCapability.value = mode
    }

    fun startNewChat() {
        cancelActiveStreamWithoutSaving()
        _activeChatId.value = null
        _streamingState.value = StreamingUiState.Idle
        _selectedCapability.value = CapabilityMode.CHAT
    }

    fun selectChat(chat: ChatSession) {
        if (_activeChatId.value == chat.id) return
        cancelActiveStreamWithoutSaving()
        _activeChatId.value = chat.id
        _selectedLanguage.value = chat.languageMode
        _streamingState.value = StreamingUiState.Idle
    }

    fun sendMessage(promptOverride: String? = null) {
        if (_cooldownSecondsRemaining.value > 0) return
        if (requestInFlight.get() || streamingJob?.isActive == true) return
        if (_streamingState.value is StreamingUiState.Connecting ||
            _streamingState.value is StreamingUiState.Streaming
        ) {
            return
        }

        val prompt = (promptOverride ?: _inputText.value).trim()
        if (prompt.isEmpty()) return

        val capability = _selectedCapability.value
        val language = _selectedLanguage.value
        val signature = "${_activeChatId.value}|${language.code}|${capability.tag}|$prompt"
        val nowMs = SystemClock.elapsedRealtime()
        if (signature == lastDispatchSignature && (nowMs - lastDispatchElapsedMs) < DUPLICATE_GUARD_WINDOW_MS) {
            return
        }
        lastDispatchSignature = signature
        lastDispatchElapsedMs = nowMs

        if (promptOverride == null) {
            _inputText.value = ""
        }

        val existingMessages = (messagesState.value as? UiState.Success)?.data.orEmpty()
        launchGeneration(
            prompt = prompt,
            historyBeforePrompt = existingMessages,
            language = language,
            capability = capability,
            skipSavingUserMessage = false
        )
    }

    fun retryLastError() {
        if (_cooldownSecondsRemaining.value > 0) return
        if (requestInFlight.get() || streamingJob?.isActive == true) return

        val errorState = _streamingState.value as? StreamingUiState.Error ?: return
        val currentMessages = (messagesState.value as? UiState.Success)?.data.orEmpty()
        val history = if (errorState.userMessageAlreadySaved && currentMessages.lastOrNull()?.isFromUser == true) {
            currentMessages.dropLast(1)
        } else {
            currentMessages
        }

        launchGeneration(
            prompt = errorState.retryPrompt,
            historyBeforePrompt = history,
            language = _selectedLanguage.value,
            capability = _selectedCapability.value,
            skipSavingUserMessage = errorState.userMessageAlreadySaved
        )
    }

    private fun launchGeneration(
        prompt: String,
        historyBeforePrompt: List<ChatMessage>,
        language: LanguageMode,
        capability: CapabilityMode,
        skipSavingUserMessage: Boolean
    ) {
        if (!requestInFlight.compareAndSet(false, true)) return

        streamingJob?.cancel()
        streamingJob = viewModelScope.launch {
            _streamingState.value = StreamingUiState.Connecting
            var targetChatId = _activeChatId.value
            var userMessageSaved = skipSavingUserMessage

            try {
                if (!userMessageSaved) {
                    if (targetChatId == null) {
                        val title = ChatRepository.deriveChatTitle(prompt)
                        val createResult = chatRepository.createChatWithUserMessage(
                            userId = currentUserId,
                            title = title,
                            languageMode = language,
                            userText = prompt,
                            capability = capability
                        )
                        val createdId = createResult.getOrElse { err ->
                            _streamingState.value = StreamingUiState.Error(
                                message = err.localizedMessage ?: "Failed to create chat.",
                                retryPrompt = prompt,
                                userMessageAlreadySaved = false
                            )
                            return@launch
                        }
                        targetChatId = createdId
                        _activeChatId.value = createdId
                        userMessageSaved = true
                    } else {
                        val nextCount = historyBeforePrompt.size.toLong() + 1L
                        val appendUserResult = chatRepository.appendMessage(
                            userId = currentUserId,
                            chatId = targetChatId,
                            role = "user",
                            text = prompt,
                            capability = capability,
                            updatedMessageCount = nextCount
                        )
                        appendUserResult.getOrElse { err ->
                            _streamingState.value = StreamingUiState.Error(
                                message = err.localizedMessage ?: "Failed to save your message.",
                                retryPrompt = prompt,
                                userMessageAlreadySaved = false
                            )
                            return@launch
                        }
                        userMessageSaved = true
                    }
                }

                val resolvedChatId = targetChatId ?: return@launch
                var latestReply = ""

                geminiAiRepository.streamReply(
                    historyMessages = historyBeforePrompt,
                    userPrompt = prompt,
                    languageMode = language,
                    capabilityMode = capability
                ).collect { accumulated ->
                    latestReply = accumulated
                    _streamingState.value = StreamingUiState.Streaming(accumulated)
                }

                val totalMessagesAfterReply = historyBeforePrompt.size.toLong() + 2L
                val saveModelResult = chatRepository.appendMessage(
                    userId = currentUserId,
                    chatId = resolvedChatId,
                    role = "model",
                    text = latestReply,
                    capability = capability,
                    updatedMessageCount = totalMessagesAfterReply
                )
                saveModelResult.onFailure { err ->
                    _bannerError.value = err.localizedMessage ?: "Could not save reply to cloud history."
                }
                _streamingState.value = StreamingUiState.Idle
            } catch (e: CancellationException) {
                throw e
            } catch (e: QuotaExhaustedException) {
                Log.w(TAG, "Free-tier quota exhausted (429)", e)
                startQuotaCooldown()
                _streamingState.value = StreamingUiState.Error(
                    message = e.localizedMessage ?: "Free quota exhausted (429).",
                    retryPrompt = prompt,
                    userMessageAlreadySaved = userMessageSaved,
                    quotaExhausted = true
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error during Sorbon AI response generation", e)
                val isQuota = GeminiAiRepository.isQuotaExhaustedError(e)
                if (isQuota) {
                    startQuotaCooldown()
                }
                _streamingState.value = StreamingUiState.Error(
                    message = e.localizedMessage ?: "Sorbon AI encountered an error. Please try again.",
                    retryPrompt = prompt,
                    userMessageAlreadySaved = userMessageSaved,
                    quotaExhausted = isQuota
                )
            } finally {
                requestInFlight.set(false)
            }
        }
    }

    private fun startQuotaCooldown() {
        cooldownJob?.cancel()
        cooldownJob = viewModelScope.launch {
            for (seconds in QUOTA_COOLDOWN_SECONDS downTo 1) {
                _cooldownSecondsRemaining.value = seconds
                delay(1_000L)
            }
            _cooldownSecondsRemaining.value = 0
        }
    }

    fun stopGenerating() {
        val currentStream = _streamingState.value
        val activeId = _activeChatId.value
        streamingJob?.cancel()
        streamingJob = null
        requestInFlight.set(false)
        _streamingState.value = StreamingUiState.Idle

        if (currentStream is StreamingUiState.Streaming &&
            currentStream.text.isNotBlank() &&
            activeId != null
        ) {
            val currentMessages = (messagesState.value as? UiState.Success)?.data.orEmpty()
            val nextCount = currentMessages.size.toLong() + 1L
            viewModelScope.launch {
                chatRepository.appendMessage(
                    userId = currentUserId,
                    chatId = activeId,
                    role = "model",
                    text = currentStream.text,
                    capability = _selectedCapability.value,
                    updatedMessageCount = nextCount
                )
            }
        }
    }

    fun renameChat(chatId: String, newTitle: String) {
        viewModelScope.launch {
            chatRepository.renameChat(currentUserId, chatId, newTitle).onFailure { err ->
                _bannerError.value = err.localizedMessage ?: "Failed to rename chat."
            }
        }
    }

    fun togglePinChat(chat: ChatSession) {
        viewModelScope.launch {
            chatRepository.togglePinChat(currentUserId, chat.id, !chat.pinned).onFailure { err ->
                _bannerError.value = err.localizedMessage ?: "Failed to update pin state."
            }
        }
    }

    fun deleteChat(chatId: String) {
        if (_activeChatId.value == chatId) {
            cancelActiveStreamWithoutSaving()
            _activeChatId.value = null
            _streamingState.value = StreamingUiState.Idle
        }
        viewModelScope.launch {
            chatRepository.deleteChat(currentUserId, chatId).onFailure { err ->
                _bannerError.value = err.localizedMessage ?: "Failed to delete chat."
            }
        }
    }

    private fun cancelActiveStreamWithoutSaving() {
        streamingJob?.cancel()
        streamingJob = null
        requestInFlight.set(false)
    }

    override fun onCleared() {
        super.onCleared()
        cancelActiveStreamWithoutSaving()
        cooldownJob?.cancel()
    }
}
