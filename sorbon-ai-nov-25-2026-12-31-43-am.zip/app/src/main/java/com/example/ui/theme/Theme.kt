package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val SorbonDarkColorScheme = darkColorScheme(
    primary = LuminousTeal,
    onPrimary = DeepMidnight,
    primaryContainer = TealContainerDark,
    onPrimaryContainer = OnTealContainerDark,
    secondary = PamirGold,
    onSecondary = DeepMidnight,
    secondaryContainer = GoldContainerDark,
    onSecondaryContainer = OnGoldContainerDark,
    tertiary = Color(0xFF38BDF8),
    onTertiary = DeepMidnight,
    background = DeepMidnight,
    onBackground = SlateTextLight,
    surface = MidnightSurface,
    onSurface = SlateTextLight,
    surfaceVariant = MidnightSurfaceHigh,
    onSurfaceVariant = SlateMutedLight,
    surfaceContainerLow = MidnightSurface,
    surfaceContainer = MidnightSurfaceHigh,
    surfaceContainerHigh = MidnightSurfaceHighest,
    outline = SlateOutlineDark,
    outlineVariant = Color(0xFF1F2E52),
    error = CoralErrorDark,
    onError = DeepMidnight,
    errorContainer = CoralErrorContainerDark,
    onErrorContainer = CoralErrorDark
)

private val SorbonLightColorScheme = lightColorScheme(
    primary = TealDeep,
    onPrimary = Color.White,
    primaryContainer = TealContainerLight,
    onPrimaryContainer = OnTealContainerLight,
    secondary = Color(0xFFD97706),
    onSecondary = Color.White,
    secondaryContainer = GoldContainerLight,
    onSecondaryContainer = OnGoldContainerLight,
    tertiary = Color(0xFF0284C7),
    onTertiary = Color.White,
    background = CloudBackground,
    onBackground = InkDark,
    surface = CloudSurface,
    onSurface = InkDark,
    surfaceVariant = CloudSurfaceHigh,
    onSurfaceVariant = InkMuted,
    surfaceContainerLow = CloudSurface,
    surfaceContainer = CloudSurfaceHigh,
    surfaceContainerHigh = CloudSurfaceHighest,
    outline = SlateOutlineLight,
    outlineVariant = Color(0xFFE2E8F0),
    error = CoralErrorLight,
    onError = Color.White,
    errorContainer = CoralErrorContainerLight,
    onErrorContainer = CoralErrorLight
)

val SorbonShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun SorbonTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) SorbonDarkColorScheme else SorbonLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = SorbonTypography,
        shapes = SorbonShapes,
        content = content
    )
}
