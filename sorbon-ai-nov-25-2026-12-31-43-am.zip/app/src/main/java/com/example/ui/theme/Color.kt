package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Midnight Lapis & Luminous Teal Palette for Sorbon AI
val DeepMidnight = Color(0xFF091430)
val MidnightSurface = Color(0xFF0E1A38)
val MidnightSurfaceHigh = Color(0xFF16254A)
val MidnightSurfaceHighest = Color(0xFF1E3261)

val LuminousTeal = Color(0xFF2DD4BF)
val TealDeep = Color(0xFF0D9488)
val TealContainerDark = Color(0xFF103E42)
val OnTealContainerDark = Color(0xFFA7F3D0)

val PamirGold = Color(0xFFF59E0B)
val GoldContainerDark = Color(0xFF422C08)
val OnGoldContainerDark = Color(0xFFFDE68A)

val SlateTextLight = Color(0xFFF1F5F9)
val SlateMutedLight = Color(0xFF94A3B8)
val SlateOutlineDark = Color(0xFF2B3D66)

// Light Theme Tokens
val CloudBackground = Color(0xFFF6F8FC)
val CloudSurface = Color(0xFFFFFFFF)
val CloudSurfaceHigh = Color(0xFFEEF2F8)
val CloudSurfaceHighest = Color(0xFFE2E8F0)

val TealContainerLight = Color(0xFFCCFBF1)
val OnTealContainerLight = Color(0xFF0F3D3E)
val GoldContainerLight = Color(0xFFFEF3C7)
val OnGoldContainerLight = Color(0xFF451A03)

val InkDark = Color(0xFF0F172A)
val InkMuted = Color(0xFF475569)
val SlateOutlineLight = Color(0xFFCBD5E1)

val CoralErrorDark = Color(0xFFFCA5A5)
val CoralErrorContainerDark = Color(0xFF5C1D24)
val CoralErrorLight = Color(0xFFDC2626)
val CoralErrorContainerLight = Color(0xFFFEE2E2)
