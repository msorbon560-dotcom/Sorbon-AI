package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class LanguageMode(
    val code: String,
    val nativeLabel: String,
    val shortBadge: String
) {
    AUTO("auto", "Auto", "AUTO"),
    TAJIK("tg", "Тоҷикӣ", "TJ"),
    RUSSIAN("ru", "Русский", "RU"),
    ENGLISH("en", "English", "EN");

    companion object {
        fun fromCode(code: String?): LanguageMode =
            entries.firstOrNull { it.code == code } ?: AUTO
    }
}

enum class CapabilityMode(
    val tag: String,
    val labelEn: String,
    val labelRu: String,
    val labelTg: String
) {
    CHAT("chat", "Ask anything", "Спросить", "Пурсидан"),
    WRITE("write", "Write text", "Написать текст", "Навиштани матн"),
    TRANSLATE("translate", "Translate", "Перевести", "Тарҷума"),
    MATH("math", "Solve math", "Математика", "Ҳалли математика");

    fun labelFor(language: LanguageMode): String = when (language) {
        LanguageMode.TAJIK -> labelTg
        LanguageMode.RUSSIAN -> labelRu
        LanguageMode.ENGLISH, LanguageMode.AUTO -> labelEn
    }

    companion object {
        fun fromTag(tag: String?): CapabilityMode =
            entries.firstOrNull { it.tag == tag } ?: CHAT
    }
}

@Keep
@IgnoreExtraProperties
data class ChatSession(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val languageCode: String = LanguageMode.AUTO.code,
    val lastMessagePreview: String = "",
    val messageCount: Long = 0L,
    val pinned: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val languageMode: LanguageMode
        get() = LanguageMode.fromCode(languageCode)
}

@Keep
@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val chatId: String = "",
    val role: String = "user",
    val text: String = "",
    val taskTag: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    val isFromUser: Boolean
        get() = role == "user"
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
