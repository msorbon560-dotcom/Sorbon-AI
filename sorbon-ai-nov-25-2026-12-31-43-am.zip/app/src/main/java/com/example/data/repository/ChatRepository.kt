package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.CapabilityMode
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.data.model.LanguageMode
import com.example.firebase.OperationType
import com.example.firebase.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ChatRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(expectedUserId: String): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
        check(uid == expectedUserId) { "Signed-in user changed; refusing cross-user operation." }
        return uid
    }

    fun observeChats(userId: String): Flow<List<ChatSession>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/chats"
        emitAll(
            db.collection("users")
                .document(uid)
                .collection("chats")
                .orderBy("updatedAt", Query.Direction.DESCENDING)
                .limit(50)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ChatSession::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMessages(userId: String, chatId: String): Flow<List<ChatMessage>> = flow {
        val uid = requireUserId(userId)
        require(chatId.isNotBlank()) { "chatId must not be blank" }
        val path = "users/$uid/chats/$chatId/messages"
        emitAll(
            db.collection("users")
                .document(uid)
                .collection("chats")
                .document(chatId)
                .collection("messages")
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .limit(100)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ChatMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun createChatWithUserMessage(
        userId: String,
        title: String,
        languageMode: LanguageMode,
        userText: String,
        capability: CapabilityMode
    ): Result<String> {
        var targetPath = "users/$userId/chats"
        return try {
            val uid = requireUserId(userId)
            val safeTitle = sanitizeTitle(title)
            val safeText = sanitizeMessageText(userText)
            val preview = sanitizePreview(safeText)

            val chatRef = db.collection("users").document(uid).collection("chats").document()
            val messageRef = chatRef.collection("messages").document()
            targetPath = chatRef.path

            val chatPayload = mapOf(
                "userId" to uid,
                "title" to safeTitle,
                "languageCode" to languageMode.code,
                "lastMessagePreview" to preview,
                "messageCount" to 1L,
                "pinned" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val messagePayload = mapOf(
                "userId" to uid,
                "chatId" to chatRef.id,
                "role" to "user",
                "text" to safeText,
                "taskTag" to capability.tag,
                "createdAt" to FieldValue.serverTimestamp()
            )

            val batch = db.batch()
            batch.set(chatRef, chatPayload)
            batch.set(messageRef, messagePayload)
            batch.commit().await()

            Result.success(chatRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, targetPath)
            Result.failure(e)
        }
    }

    suspend fun appendMessage(
        userId: String,
        chatId: String,
        role: String,
        text: String,
        capability: CapabilityMode?,
        updatedMessageCount: Long
    ): Result<Unit> {
        var targetPath = "users/$userId/chats/$chatId/messages"
        return try {
            val uid = requireUserId(userId)
            require(chatId.isNotBlank()) { "chatId must not be blank" }
            require(role == "user" || role == "model") { "Invalid message role: $role" }

            val safeText = sanitizeMessageText(text)
            val preview = sanitizePreview(safeText)
            val chatRef = db.collection("users").document(uid).collection("chats").document(chatId)
            val messageRef = chatRef.collection("messages").document()
            targetPath = messageRef.path

            val messagePayload = buildMap<String, Any> {
                put("userId", uid)
                put("chatId", chatId)
                put("role", role)
                put("text", safeText)
                if (capability != null) {
                    put("taskTag", capability.tag)
                }
                put("createdAt", FieldValue.serverTimestamp())
            }

            val chatUpdatePayload = mapOf(
                "lastMessagePreview" to preview,
                "messageCount" to updatedMessageCount.coerceAtLeast(1L),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val batch = db.batch()
            batch.set(messageRef, messagePayload)
            batch.update(chatRef, chatUpdatePayload)
            batch.commit().await()

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, targetPath)
            Result.failure(e)
        }
    }

    suspend fun renameChat(userId: String, chatId: String, newTitle: String): Result<Unit> {
        val docPath = "users/$userId/chats/$chatId"
        return try {
            val uid = requireUserId(userId)
            require(chatId.isNotBlank()) { "chatId must not be blank" }
            val safeTitle = sanitizeTitle(newTitle)
            db.collection("users").document(uid).collection("chats").document(chatId)
                .update(
                    mapOf(
                        "title" to safeTitle,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun togglePinChat(userId: String, chatId: String, pinned: Boolean): Result<Unit> {
        val docPath = "users/$userId/chats/$chatId"
        return try {
            val uid = requireUserId(userId)
            require(chatId.isNotBlank()) { "chatId must not be blank" }
            db.collection("users").document(uid).collection("chats").document(chatId)
                .update(
                    mapOf(
                        "pinned" to pinned,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateChatLanguage(
        userId: String,
        chatId: String,
        languageMode: LanguageMode
    ): Result<Unit> {
        val docPath = "users/$userId/chats/$chatId"
        return try {
            val uid = requireUserId(userId)
            require(chatId.isNotBlank()) { "chatId must not be blank" }
            db.collection("users").document(uid).collection("chats").document(chatId)
                .update(
                    mapOf(
                        "languageCode" to languageMode.code,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteChat(userId: String, chatId: String): Result<Unit> {
        val docPath = "users/$userId/chats/$chatId"
        return try {
            val uid = requireUserId(userId)
            require(chatId.isNotBlank()) { "chatId must not be blank" }
            val chatRef = db.collection("users").document(uid).collection("chats").document(chatId)
            val messagesSnapshot = chatRef.collection("messages").get().await()

            val chunks = messagesSnapshot.documents.chunked(400)
            if (chunks.isEmpty()) {
                chatRef.delete().await()
            } else {
                chunks.forEachIndexed { index, docs ->
                    val batch = db.batch()
                    docs.forEach { batch.delete(it.reference) }
                    if (index == chunks.lastIndex) {
                        batch.delete(chatRef)
                    }
                    batch.commit().await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    companion object {
        fun deriveChatTitle(prompt: String): String {
            val singleLine = prompt.trim().replace(Regex("\\s+"), " ")
            if (singleLine.isEmpty()) return "New chat"
            return if (singleLine.length <= 54) singleLine else singleLine.take(51).trimEnd() + "..."
        }

        private fun sanitizeTitle(title: String): String {
            val cleaned = title.trim().replace(Regex("\\s+"), " ")
            return if (cleaned.isEmpty()) "New chat" else cleaned.take(120)
        }

        private fun sanitizeMessageText(text: String): String {
            val cleaned = text.trim()
            require(cleaned.isNotEmpty()) { "Message text cannot be empty" }
            return cleaned.take(32000)
        }

        private fun sanitizePreview(text: String): String {
            val singleLine = text.trim().replace(Regex("\\s+"), " ")
            return if (singleLine.length <= 140) singleLine else singleLine.take(137).trimEnd() + "..."
        }
    }
}
