package com.example.data.repository

import android.util.Log
import com.example.data.model.CapabilityMode
import com.example.data.model.ChatMessage
import com.example.data.model.LanguageMode
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout

private const val TAG = "GeminiAiRepository"

// Free-tier Gemini models only (no Firebase Blaze billing required)
private const val FREE_TIER_LITE_MODEL = "gemini-3.5-flash-lite"
private const val FREE_TIER_FLASH_MODEL = "gemini-3.8-flash"

private const val STREAM_TIMEOUT_MS = 60_000L
private const val MAX_HISTORY_MESSAGES = 10
private const val MAX_HISTORY_CHARS_PER_MESSAGE = 1_000
private const val MAX_OUTPUT_TOKENS = 1_024
private const val MAX_CACHE_ENTRIES = 32

class QuotaExhaustedException(
    message: String = "Free quota exhausted (429).",
    cause: Throwable? = null
) : Exception(message, cause)

class GeminiAiRepository {

    // Lazy initialization per (model, language) pair to avoid eager Firebase.ai lookup
    private val modelCache = mutableMapOf<Pair<String, LanguageMode>, GenerativeModel>()

    // Lightweight in-memory LRU cache for standalone (no-history) prompts to reduce duplicate API calls
    private val standaloneResponseCache = object : LinkedHashMap<String, String>(
        MAX_CACHE_ENTRIES + 1,
        0.75f,
        true
    ) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
            return size > MAX_CACHE_ENTRIES
        }
    }

    private fun modelFor(languageMode: LanguageMode, capabilityMode: CapabilityMode): GenerativeModel {
        // Use ultra-efficient free-tier Flash-Lite for general chat, writing, and translation,
        // and free-tier 3.8 Flash for step-by-step math reasoning.
        val modelName = when (capabilityMode) {
            CapabilityMode.MATH -> FREE_TIER_FLASH_MODEL
            CapabilityMode.CHAT,
            CapabilityMode.WRITE,
            CapabilityMode.TRANSLATE -> FREE_TIER_LITE_MODEL
        }
        return synchronized(modelCache) {
            modelCache.getOrPut(modelName to languageMode) {
                createModel(modelName, languageMode)
            }
        }
    }

    private fun createModel(modelName: String, languageMode: LanguageMode): GenerativeModel {
        val languageDirective = when (languageMode) {
            LanguageMode.TAJIK ->
                "Reply in Tajik Cyrillic (Тоҷикӣ: Ғ, Ӣ, Қ, Ӯ, Ҳ, Ҷ) unless asked to translate."
            LanguageMode.RUSSIAN ->
                "Reply in natural Russian (Русский) unless asked to translate."
            LanguageMode.ENGLISH ->
                "Reply in clear English unless asked to translate."
            LanguageMode.AUTO ->
                "Mirror the user's language (Tajik, Russian, or English) unless translating."
        }

        // Concise system instruction to minimize input tokens on every call
        val instructionText = """
            You are Sorbon AI, a helpful multilingual assistant fluent in Tajik (Тоҷикӣ), Russian, and English.
            Help with Q&A, writing, Tajik/Russian/English translation, and step-by-step math.
            $languageDirective
            Be clear, accurate, and concise using mobile-friendly Markdown.
        """.trimIndent()

        val config = generationConfig {
            temperature = 0.65f
            topP = 0.95f
            maxOutputTokens = MAX_OUTPUT_TOKENS
        }

        return Firebase.ai.generativeModel(
            modelName = modelName,
            generationConfig = config,
            systemInstruction = content { text(instructionText) }
        )
    }

    fun streamReply(
        historyMessages: List<ChatMessage>,
        userPrompt: String,
        languageMode: LanguageMode,
        capabilityMode: CapabilityMode
    ): Flow<String> = flow {
        val normalizedPrompt = userPrompt.trim()
        val cacheKey = if (historyMessages.isEmpty()) {
            buildCacheKey(normalizedPrompt, languageMode, capabilityMode)
        } else {
            null
        }

        if (cacheKey != null) {
            val cached = synchronized(standaloneResponseCache) { standaloneResponseCache[cacheKey] }
            if (!cached.isNullOrBlank()) {
                emit(cached)
                return@flow
            }
        }

        val model = modelFor(languageMode, capabilityMode)
        val trimmedHistory: List<Content> = historyMessages
            .takeLast(MAX_HISTORY_MESSAGES)
            .map { msg ->
                val role = if (msg.role == "model") "model" else "user"
                val compactText = if (msg.text.length > MAX_HISTORY_CHARS_PER_MESSAGE) {
                    msg.text.take(MAX_HISTORY_CHARS_PER_MESSAGE) + "…"
                } else {
                    msg.text
                }
                content(role) { text(compactText) }
            }

        val chat = model.startChat(history = trimmedHistory)
        val effectivePrompt = buildEffectivePrompt(normalizedPrompt, capabilityMode)
        val accumulated = StringBuilder()

        try {
            withTimeout(STREAM_TIMEOUT_MS) {
                chat.sendMessageStream(effectivePrompt).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        accumulated.append(piece)
                        emit(accumulated.toString())
                    }
                }
            }
            val finalReply = accumulated.toString()
            if (finalReply.isBlank()) {
                throw IllegalStateException("Sorbon AI returned an empty response. Please try again.")
            }
            if (cacheKey != null) {
                synchronized(standaloneResponseCache) {
                    standaloneResponseCache[cacheKey] = finalReply
                }
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini streaming timed out", e)
            throw IllegalStateException("Response timed out after 60 seconds. Please try again.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini streaming failed", e)
            if (isQuotaExhaustedError(e)) {
                throw QuotaExhaustedException(cause = e)
            }
            throw e
        }
    }

    private fun buildCacheKey(
        prompt: String,
        languageMode: LanguageMode,
        capabilityMode: CapabilityMode
    ): String {
        val compactPrompt = prompt.lowercase().replace(Regex("\\s+"), " ")
        return "${languageMode.code}|${capabilityMode.tag}|$compactPrompt"
    }

    private fun buildEffectivePrompt(prompt: String, capability: CapabilityMode): String {
        return when (capability) {
            CapabilityMode.CHAT -> prompt
            CapabilityMode.TRANSLATE -> "[Translate TJ/RU/EN]\n$prompt"
            CapabilityMode.MATH -> "[Step-by-step math]\n$prompt"
            CapabilityMode.WRITE -> "[Write text]\n$prompt"
        }
    }

    companion object {
        fun isQuotaExhaustedError(throwable: Throwable): Boolean {
            return generateSequence(throwable) { it.cause }.any { err ->
                val className = err::class.java.simpleName.lowercase()
                val msg = err.message.orEmpty().lowercase()
                className.contains("quotaexceeded") ||
                    className.contains("toomanyrequests") ||
                    msg.contains("429") ||
                    msg.contains("resource_exhausted") ||
                    msg.contains("quota") ||
                    msg.contains("rate limit") ||
                    msg.contains("too many requests")
            }
        }
    }
}
