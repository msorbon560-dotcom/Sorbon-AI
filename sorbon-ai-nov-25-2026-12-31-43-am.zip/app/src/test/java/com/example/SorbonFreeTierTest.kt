package com.example

import com.example.data.model.CapabilityMode
import com.example.data.model.LanguageMode
import com.example.data.repository.GeminiAiRepository
import com.example.data.repository.QuotaExhaustedException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SorbonFreeTierTest {

    @Test
    fun detects429AndQuotaErrorsInExceptionChain() {
        assertTrue(
            GeminiAiRepository.isQuotaExhaustedError(
                RuntimeException("HTTP 429 Too Many Requests")
            )
        )
        assertTrue(
            GeminiAiRepository.isQuotaExhaustedError(
                IllegalStateException("Wrapper", RuntimeException("RESOURCE_EXHAUSTED: quota exceeded"))
            )
        )
        assertTrue(
            GeminiAiRepository.isQuotaExhaustedError(QuotaExhaustedException())
        )
        assertFalse(
            GeminiAiRepository.isQuotaExhaustedError(
                IllegalStateException("Network connection reset by peer")
            )
        )
    }

    @Test
    fun languageAndCapabilityModesRemainIntact() {
        assertEquals(LanguageMode.TAJIK, LanguageMode.fromCode("tg"))
        assertEquals(LanguageMode.RUSSIAN, LanguageMode.fromCode("ru"))
        assertEquals(LanguageMode.ENGLISH, LanguageMode.fromCode("en"))
        assertEquals(LanguageMode.AUTO, LanguageMode.fromCode("unknown"))

        assertEquals("Тарҷума", CapabilityMode.TRANSLATE.labelFor(LanguageMode.TAJIK))
        assertEquals("Перевести", CapabilityMode.TRANSLATE.labelFor(LanguageMode.RUSSIAN))
        assertEquals("Translate", CapabilityMode.TRANSLATE.labelFor(LanguageMode.ENGLISH))
    }
}
